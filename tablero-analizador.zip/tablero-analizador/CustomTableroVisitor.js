// jshint ignore: start
import TableroVisitor from './generated/TableroVisitor.js';

/**
 * CustomTableroVisitor
 * Extiende el Visitor generado por ANTLR para:
 *  1. Recopilar información semántica del árbol
 *  2. Traducir el programa Tablero a JavaScript ejecutable
 */
export default class CustomTableroVisitor extends TableroVisitor {
    constructor() {
        super();
        this.jsLines = [];
        this.fuentes = {};
        this.metricas = {};
        this.graficos = {};
        this.filtros = [];
        this.alertas = [];
        this.erroresSemanticos = [];
    }

    // Helper: convierte valor Tablero a representación JS segura
    _valorJS(valText) {
        // si empieza con " es cadena, devolvemos tal cual (ya está en comillas dobles)
        if (valText.startsWith('"')) return valText;
        // booleano
        if (valText === 'verdadero') return 'true';
        if (valText === 'falso') return 'false';
        // número
        return valText;
    }

    // Helper: escapa texto para usar dentro de console.log string
    _escapeLog(text) {
        return text.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    }

    // ---------------------------------------------------------
    // programa: 'tablero' identificador '{' elemento* '}' ';'
    // ---------------------------------------------------------
    visitPrograma(ctx) {
        const nombre = ctx.identificador().getText();
        this.jsLines.push(`// === Tablero: ${nombre} ===`);
        this.jsLines.push(`// Código JavaScript generado automáticamente por el Analizador Tablero`);
        this.jsLines.push(`// SSL - Sintaxis y Semántica de LP - UTN FRM\n`);
        this.jsLines.push(`const tablero = { nombre: "${nombre}", fuentes: {}, metricas: {}, graficos: [], filtros: [], alertas: [] };\n`);

        for (const elem of (ctx.elemento() || [])) {
            this.visit(elem);
        }

        // Bloque de ejecución
        this.jsLines.push(`\n// --- Ejecución de métricas ---`);
        for (const [id, m] of Object.entries(this.metricas)) {
            this.jsLines.push(`console.log("  Métrica '${id}': ${m.agregacion}(${m.campo}) -> fuente: '${m.fuente}' -> valor simulado: " + tablero.metricas["${id}"].valorSimulado);`);
        }

        this.jsLines.push(`\n// --- Renderizado de gráficos ---`);
        for (const [id, g] of Object.entries(this.graficos)) {
            this.jsLines.push(`console.log("  Gráfico '${id}' [${g.tipo}] usando métrica '${g.usar}'");`);
        }

        this.jsLines.push(`\n// --- Evaluación de filtros ---`);
        for (const f of this.filtros) {
            const valDisplay = this._escapeLog(f.valor);
            this.jsLines.push(`console.log("  Filtro activo: ${this._escapeLog(f.campo)} ${f.operador} ${valDisplay}");`);
        }

        this.jsLines.push(`\n// --- Evaluación de alertas ---`);
        for (const a of this.alertas) {
            this.jsLines.push(`{`);
            this.jsLines.push(`  const _val = tablero.metricas["${a.id}"] ? tablero.metricas["${a.id}"].valorSimulado : 0;`);
            this.jsLines.push(`  if (_val ${a.opJS} ${a.valorJS}) {`);
            this.jsLines.push(`    console.log("  \u26a0 ALERTA ACTIVADA [${a.id}]: " + ${a.mensajeJS});`);
            this.jsLines.push(`  } else {`);
            this.jsLines.push(`    console.log("  \u2713 Alerta '${a.id}': sin activar (valor=" + _val + ")");`);
            this.jsLines.push(`  }`);
            this.jsLines.push(`}`);
        }

        this.jsLines.push(`\nconsole.log("\\n=== Tablero '${nombre}' procesado correctamente ===");`);

        return this.jsLines.join('\n');
    }

    visitElemento(ctx) { return this.visitChildren(ctx); }

    // ---------------------------------------------------------
    // fuente: 'fuente' identificador 'tipo' tipo_fuente 'ruta' cadena ';'
    // ---------------------------------------------------------
    visitFuente(ctx) {
        const id = ctx.identificador().getText();
        const tipo = ctx.tipo_fuente().getText();
        const ruta = ctx.cadena().getText();

        this.fuentes[id] = { tipo, ruta };

        this.jsLines.push(`// Fuente: ${id}`);
        this.jsLines.push(`tablero.fuentes["${id}"] = { tipo: "${tipo}", ruta: ${ruta} };`);
        this.jsLines.push(`console.log("  Fuente cargada: '${id}' (tipo: ${tipo}) desde " + tablero.fuentes["${id}"].ruta);`);
        return null;
    }

    // ---------------------------------------------------------
    // metrica: 'metrica' identificador '=' agregacion '(' campo ')' ';'
    // ---------------------------------------------------------
    visitMetrica(ctx) {
        const id = ctx.identificador().getText();
        const agr = ctx.agregacion().getText();
        const campo = ctx.campo().getText();
        const fuenteRef = campo.split('.')[0];

        if (!this.fuentes[fuenteRef]) {
            this.erroresSemanticos.push(`La métrica '${id}' referencia la fuente '${fuenteRef}' que no fue declarada previamente.`);
        }

        // Valores simulados para la interpretación
        const valSim = agr === 'contar' ? 100 : agr === 'suma' ? 5000 : agr === 'promedio' ? 42.5 : agr === 'maximo' ? 99 : 1;
        this.metricas[id] = { agregacion: agr, campo, fuente: fuenteRef, valorSimulado: valSim };

        this.jsLines.push(`\n// Métrica: ${id}`);
        this.jsLines.push(`tablero.metricas["${id}"] = { agregacion: "${agr}", campo: "${campo}", fuente: "${fuenteRef}", valorSimulado: ${valSim} };`);
        return null;
    }

    // ---------------------------------------------------------
    // grafico: 'grafico' identificador '{' 'tipo' '=' tipo_grafico ';' 'usar' '=' identificador ';' '}'
    // ---------------------------------------------------------
    visitGrafico(ctx) {
        const ids = ctx.identificador();
        const id = ids[0].getText();
        const usar = ids[1].getText();
        const tipo = ctx.tipo_grafico().getText();

        if (!this.metricas[usar]) {
            this.erroresSemanticos.push(`El gráfico '${id}' usa la métrica '${usar}' que no fue declarada previamente.`);
        }

        this.graficos[id] = { tipo, usar };

        this.jsLines.push(`\n// Gráfico: ${id}`);
        this.jsLines.push(`tablero.graficos.push({ id: "${id}", tipo: "${tipo}", usar: "${usar}" });`);
        return null;
    }

    // ---------------------------------------------------------
    // filtro: 'filtro' campo operador valor ';'
    // ---------------------------------------------------------
    visitFiltro(ctx) {
        const campo = ctx.campo().getText();
        const op = ctx.operador().getText();
        const val = ctx.valor().getText();
        const valJS = this._valorJS(val);

        this.filtros.push({ campo, operador: op, valor: val });

        this.jsLines.push(`\n// Filtro: ${campo} ${op} ${val}`);
        this.jsLines.push(`tablero.filtros.push({ campo: "${campo}", operador: "${op}", valor: ${valJS} });`);
        return null;
    }

    // ---------------------------------------------------------
    // alerta: 'alerta' 'si' identificador operador valor 'entonces' cadena ';'
    // ---------------------------------------------------------
    visitAlerta(ctx) {
        const id = ctx.identificador().getText();
        const op = ctx.operador().getText();
        const val = ctx.valor().getText();
        const msg = ctx.cadena().getText();
        const valJS = this._valorJS(val);
        const opJS = op; // == != > < >= <=

        this.alertas.push({ id, operador: op, opJS, valor: val, valorJS: valJS, mensajeJS: msg });

        this.jsLines.push(`\n// Alerta: si ${id} ${op} ${val}`);
        this.jsLines.push(`tablero.alertas.push({ metrica: "${id}", operador: "${op}", valor: ${valJS}, mensaje: ${msg} });`);
        return null;
    }

    // Nodos terminales
    visitIdentificador(ctx) { return ctx.getText(); }
    visitCadena(ctx) { return ctx.getText(); }
    visitNumero(ctx) { return ctx.getText(); }
    visitBooleano(ctx) { return ctx.getText(); }
    visitCampo(ctx) { return ctx.getText(); }
    visitTipo_fuente(ctx) { return ctx.getText(); }
    visitAgregacion(ctx) { return ctx.getText(); }
    visitTipo_grafico(ctx) { return ctx.getText(); }
    visitOperador(ctx) { return ctx.getText(); }
    visitValor(ctx) { return ctx.getText(); }
}
