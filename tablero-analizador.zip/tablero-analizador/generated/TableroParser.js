// Generated from java-escape by ANTLR 4.11.1
// jshint ignore: start
import antlr4 from 'antlr4';
import TableroListener from './TableroListener.js';
import TableroVisitor from './TableroVisitor.js';

const serializedATN = [4,1,43,128,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,
4,2,5,7,5,2,6,7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,
2,13,7,13,2,14,7,14,2,15,7,15,2,16,7,16,1,0,1,0,1,0,1,0,5,0,39,8,0,10,0,
12,0,42,9,0,1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,3,1,52,8,1,1,2,1,2,1,2,1,2,1,
2,1,2,1,2,1,2,1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,5,1,5,1,6,1,
6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,7,1,7,1,8,1,8,1,8,1,8,1,
8,1,8,1,9,1,9,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,11,1,11,1,11,
5,11,110,8,11,10,11,12,11,113,9,11,1,12,1,12,1,12,3,12,118,8,12,1,13,1,13,
1,14,1,14,1,15,1,15,1,16,1,16,1,16,0,0,17,0,2,4,6,8,10,12,14,16,18,20,22,
24,26,28,30,32,0,5,1,0,12,14,1,0,15,19,1,0,20,23,1,0,26,31,1,0,24,25,118,
0,34,1,0,0,0,2,51,1,0,0,0,4,53,1,0,0,0,6,61,1,0,0,0,8,63,1,0,0,0,10,72,1,
0,0,0,12,74,1,0,0,0,14,87,1,0,0,0,16,89,1,0,0,0,18,95,1,0,0,0,20,97,1,0,
0,0,22,106,1,0,0,0,24,117,1,0,0,0,26,119,1,0,0,0,28,121,1,0,0,0,30,123,1,
0,0,0,32,125,1,0,0,0,34,35,5,1,0,0,35,36,3,28,14,0,36,40,5,33,0,0,37,39,
3,2,1,0,38,37,1,0,0,0,39,42,1,0,0,0,40,38,1,0,0,0,40,41,1,0,0,0,41,43,1,
0,0,0,42,40,1,0,0,0,43,44,5,34,0,0,44,45,5,37,0,0,45,1,1,0,0,0,46,52,3,4,
2,0,47,52,3,8,4,0,48,52,3,12,6,0,49,52,3,16,8,0,50,52,3,20,10,0,51,46,1,
0,0,0,51,47,1,0,0,0,51,48,1,0,0,0,51,49,1,0,0,0,51,50,1,0,0,0,52,3,1,0,0,
0,53,54,5,2,0,0,54,55,3,28,14,0,55,56,5,3,0,0,56,57,3,6,3,0,57,58,5,4,0,
0,58,59,3,30,15,0,59,60,5,37,0,0,60,5,1,0,0,0,61,62,7,0,0,0,62,7,1,0,0,0,
63,64,5,5,0,0,64,65,3,28,14,0,65,66,5,32,0,0,66,67,3,10,5,0,67,68,5,35,0,
0,68,69,3,22,11,0,69,70,5,36,0,0,70,71,5,37,0,0,71,9,1,0,0,0,72,73,7,1,0,
0,73,11,1,0,0,0,74,75,5,6,0,0,75,76,3,28,14,0,76,77,5,33,0,0,77,78,5,3,0,
0,78,79,5,32,0,0,79,80,3,14,7,0,80,81,5,37,0,0,81,82,5,7,0,0,82,83,5,32,
0,0,83,84,3,28,14,0,84,85,5,37,0,0,85,86,5,34,0,0,86,13,1,0,0,0,87,88,7,
2,0,0,88,15,1,0,0,0,89,90,5,8,0,0,90,91,3,22,11,0,91,92,3,18,9,0,92,93,3,
24,12,0,93,94,5,37,0,0,94,17,1,0,0,0,95,96,7,3,0,0,96,19,1,0,0,0,97,98,5,
9,0,0,98,99,5,10,0,0,99,100,3,28,14,0,100,101,3,18,9,0,101,102,3,24,12,0,
102,103,5,11,0,0,103,104,3,30,15,0,104,105,5,37,0,0,105,21,1,0,0,0,106,111,
3,28,14,0,107,108,5,38,0,0,108,110,3,28,14,0,109,107,1,0,0,0,110,113,1,0,
0,0,111,109,1,0,0,0,111,112,1,0,0,0,112,23,1,0,0,0,113,111,1,0,0,0,114,118,
3,30,15,0,115,118,3,32,16,0,116,118,3,26,13,0,117,114,1,0,0,0,117,115,1,
0,0,0,117,116,1,0,0,0,118,25,1,0,0,0,119,120,7,4,0,0,120,27,1,0,0,0,121,
122,5,39,0,0,122,29,1,0,0,0,123,124,5,41,0,0,124,31,1,0,0,0,125,126,5,40,
0,0,126,33,1,0,0,0,4,40,51,111,117];


const atn = new antlr4.atn.ATNDeserializer().deserialize(serializedATN);

const decisionsToDFA = atn.decisionToState.map( (ds, index) => new antlr4.dfa.DFA(ds, index) );

const sharedContextCache = new antlr4.PredictionContextCache();

export default class TableroParser extends antlr4.Parser {

    static grammarFileName = "java-escape";
    static literalNames = [ null, "'tablero'", "'fuente'", "'tipo'", "'ruta'", 
                            "'metrica'", "'grafico'", "'usar'", "'filtro'", 
                            "'alerta'", "'si'", "'entonces'", "'csv'", "'api'", 
                            "'json'", "'suma'", "'promedio'", "'maximo'", 
                            "'minimo'", "'contar'", "'barras'", "'lineas'", 
                            "'torta'", "'tabla'", "'verdadero'", "'falso'", 
                            "'=='", "'!='", "'>='", "'<='", "'>'", "'<'", 
                            "'='", "'{'", "'}'", "'('", "')'", "';'", "'.'" ];
    static symbolicNames = [ null, "TABLERO", "FUENTE", "TIPO", "RUTA", 
                             "METRICA", "GRAFICO", "USAR", "FILTRO", "ALERTA", 
                             "SI", "ENTONCES", "CSV", "API", "JSON_T", "SUMA", 
                             "PROMEDIO", "MAXIMO", "MINIMO", "CONTAR", "BARRAS", 
                             "LINEAS", "TORTA", "TABLA", "VERDADERO", "FALSO", 
                             "EQ", "NEQ", "GTE", "LTE", "GT", "LT", "ASSIGN", 
                             "LBRACE", "RBRACE", "LPAREN", "RPAREN", "SEMICOLON", 
                             "DOT", "ID", "NUMBER", "STRING", "WS", "COMMENT" ];
    static ruleNames = [ "programa", "elemento", "fuente", "tipo_fuente", 
                         "metrica", "agregacion", "grafico", "tipo_grafico", 
                         "filtro", "operador", "alerta", "campo", "valor", 
                         "booleano", "identificador", "cadena", "numero" ];

    constructor(input) {
        super(input);
        this._interp = new antlr4.atn.ParserATNSimulator(this, atn, decisionsToDFA, sharedContextCache);
        this.ruleNames = TableroParser.ruleNames;
        this.literalNames = TableroParser.literalNames;
        this.symbolicNames = TableroParser.symbolicNames;
    }

    get atn() {
        return atn;
    }



	programa() {
	    let localctx = new ProgramaContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 0, TableroParser.RULE_programa);
	    var _la = 0; // Token type
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 34;
	        this.match(TableroParser.TABLERO);
	        this.state = 35;
	        this.identificador();
	        this.state = 36;
	        this.match(TableroParser.LBRACE);
	        this.state = 40;
	        this._errHandler.sync(this);
	        _la = this._input.LA(1);
	        while((((_la) & ~0x1f) == 0 && ((1 << _la) & 868) !== 0)) {
	            this.state = 37;
	            this.elemento();
	            this.state = 42;
	            this._errHandler.sync(this);
	            _la = this._input.LA(1);
	        }
	        this.state = 43;
	        this.match(TableroParser.RBRACE);
	        this.state = 44;
	        this.match(TableroParser.SEMICOLON);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	elemento() {
	    let localctx = new ElementoContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 2, TableroParser.RULE_elemento);
	    try {
	        this.state = 51;
	        this._errHandler.sync(this);
	        switch(this._input.LA(1)) {
	        case 2:
	            this.enterOuterAlt(localctx, 1);
	            this.state = 46;
	            this.fuente();
	            break;
	        case 5:
	            this.enterOuterAlt(localctx, 2);
	            this.state = 47;
	            this.metrica();
	            break;
	        case 6:
	            this.enterOuterAlt(localctx, 3);
	            this.state = 48;
	            this.grafico();
	            break;
	        case 8:
	            this.enterOuterAlt(localctx, 4);
	            this.state = 49;
	            this.filtro();
	            break;
	        case 9:
	            this.enterOuterAlt(localctx, 5);
	            this.state = 50;
	            this.alerta();
	            break;
	        default:
	            throw new antlr4.error.NoViableAltException(this);
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	fuente() {
	    let localctx = new FuenteContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 4, TableroParser.RULE_fuente);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 53;
	        this.match(TableroParser.FUENTE);
	        this.state = 54;
	        this.identificador();
	        this.state = 55;
	        this.match(TableroParser.TIPO);
	        this.state = 56;
	        this.tipo_fuente();
	        this.state = 57;
	        this.match(TableroParser.RUTA);
	        this.state = 58;
	        this.cadena();
	        this.state = 59;
	        this.match(TableroParser.SEMICOLON);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	tipo_fuente() {
	    let localctx = new Tipo_fuenteContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 6, TableroParser.RULE_tipo_fuente);
	    var _la = 0; // Token type
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 61;
	        _la = this._input.LA(1);
	        if(!((((_la) & ~0x1f) == 0 && ((1 << _la) & 28672) !== 0))) {
	        this._errHandler.recoverInline(this);
	        }
	        else {
	        	this._errHandler.reportMatch(this);
	            this.consume();
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	metrica() {
	    let localctx = new MetricaContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 8, TableroParser.RULE_metrica);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 63;
	        this.match(TableroParser.METRICA);
	        this.state = 64;
	        this.identificador();
	        this.state = 65;
	        this.match(TableroParser.ASSIGN);
	        this.state = 66;
	        this.agregacion();
	        this.state = 67;
	        this.match(TableroParser.LPAREN);
	        this.state = 68;
	        this.campo();
	        this.state = 69;
	        this.match(TableroParser.RPAREN);
	        this.state = 70;
	        this.match(TableroParser.SEMICOLON);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	agregacion() {
	    let localctx = new AgregacionContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 10, TableroParser.RULE_agregacion);
	    var _la = 0; // Token type
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 72;
	        _la = this._input.LA(1);
	        if(!((((_la) & ~0x1f) == 0 && ((1 << _la) & 1015808) !== 0))) {
	        this._errHandler.recoverInline(this);
	        }
	        else {
	        	this._errHandler.reportMatch(this);
	            this.consume();
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	grafico() {
	    let localctx = new GraficoContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 12, TableroParser.RULE_grafico);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 74;
	        this.match(TableroParser.GRAFICO);
	        this.state = 75;
	        this.identificador();
	        this.state = 76;
	        this.match(TableroParser.LBRACE);
	        this.state = 77;
	        this.match(TableroParser.TIPO);
	        this.state = 78;
	        this.match(TableroParser.ASSIGN);
	        this.state = 79;
	        this.tipo_grafico();
	        this.state = 80;
	        this.match(TableroParser.SEMICOLON);
	        this.state = 81;
	        this.match(TableroParser.USAR);
	        this.state = 82;
	        this.match(TableroParser.ASSIGN);
	        this.state = 83;
	        this.identificador();
	        this.state = 84;
	        this.match(TableroParser.SEMICOLON);
	        this.state = 85;
	        this.match(TableroParser.RBRACE);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	tipo_grafico() {
	    let localctx = new Tipo_graficoContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 14, TableroParser.RULE_tipo_grafico);
	    var _la = 0; // Token type
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 87;
	        _la = this._input.LA(1);
	        if(!((((_la) & ~0x1f) == 0 && ((1 << _la) & 15728640) !== 0))) {
	        this._errHandler.recoverInline(this);
	        }
	        else {
	        	this._errHandler.reportMatch(this);
	            this.consume();
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	filtro() {
	    let localctx = new FiltroContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 16, TableroParser.RULE_filtro);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 89;
	        this.match(TableroParser.FILTRO);
	        this.state = 90;
	        this.campo();
	        this.state = 91;
	        this.operador();
	        this.state = 92;
	        this.valor();
	        this.state = 93;
	        this.match(TableroParser.SEMICOLON);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	operador() {
	    let localctx = new OperadorContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 18, TableroParser.RULE_operador);
	    var _la = 0; // Token type
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 95;
	        _la = this._input.LA(1);
	        if(!((((_la) & ~0x1f) == 0 && ((1 << _la) & 4227858432) !== 0))) {
	        this._errHandler.recoverInline(this);
	        }
	        else {
	        	this._errHandler.reportMatch(this);
	            this.consume();
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	alerta() {
	    let localctx = new AlertaContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 20, TableroParser.RULE_alerta);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 97;
	        this.match(TableroParser.ALERTA);
	        this.state = 98;
	        this.match(TableroParser.SI);
	        this.state = 99;
	        this.identificador();
	        this.state = 100;
	        this.operador();
	        this.state = 101;
	        this.valor();
	        this.state = 102;
	        this.match(TableroParser.ENTONCES);
	        this.state = 103;
	        this.cadena();
	        this.state = 104;
	        this.match(TableroParser.SEMICOLON);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	campo() {
	    let localctx = new CampoContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 22, TableroParser.RULE_campo);
	    var _la = 0; // Token type
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 106;
	        this.identificador();
	        this.state = 111;
	        this._errHandler.sync(this);
	        _la = this._input.LA(1);
	        while(_la===38) {
	            this.state = 107;
	            this.match(TableroParser.DOT);
	            this.state = 108;
	            this.identificador();
	            this.state = 113;
	            this._errHandler.sync(this);
	            _la = this._input.LA(1);
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	valor() {
	    let localctx = new ValorContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 24, TableroParser.RULE_valor);
	    try {
	        this.state = 117;
	        this._errHandler.sync(this);
	        switch(this._input.LA(1)) {
	        case 41:
	            this.enterOuterAlt(localctx, 1);
	            this.state = 114;
	            this.cadena();
	            break;
	        case 40:
	            this.enterOuterAlt(localctx, 2);
	            this.state = 115;
	            this.numero();
	            break;
	        case 24:
	        case 25:
	            this.enterOuterAlt(localctx, 3);
	            this.state = 116;
	            this.booleano();
	            break;
	        default:
	            throw new antlr4.error.NoViableAltException(this);
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	booleano() {
	    let localctx = new BooleanoContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 26, TableroParser.RULE_booleano);
	    var _la = 0; // Token type
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 119;
	        _la = this._input.LA(1);
	        if(!(_la===24 || _la===25)) {
	        this._errHandler.recoverInline(this);
	        }
	        else {
	        	this._errHandler.reportMatch(this);
	            this.consume();
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	identificador() {
	    let localctx = new IdentificadorContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 28, TableroParser.RULE_identificador);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 121;
	        this.match(TableroParser.ID);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	cadena() {
	    let localctx = new CadenaContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 30, TableroParser.RULE_cadena);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 123;
	        this.match(TableroParser.STRING);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	numero() {
	    let localctx = new NumeroContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 32, TableroParser.RULE_numero);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 125;
	        this.match(TableroParser.NUMBER);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}


}

TableroParser.EOF = antlr4.Token.EOF;
TableroParser.TABLERO = 1;
TableroParser.FUENTE = 2;
TableroParser.TIPO = 3;
TableroParser.RUTA = 4;
TableroParser.METRICA = 5;
TableroParser.GRAFICO = 6;
TableroParser.USAR = 7;
TableroParser.FILTRO = 8;
TableroParser.ALERTA = 9;
TableroParser.SI = 10;
TableroParser.ENTONCES = 11;
TableroParser.CSV = 12;
TableroParser.API = 13;
TableroParser.JSON_T = 14;
TableroParser.SUMA = 15;
TableroParser.PROMEDIO = 16;
TableroParser.MAXIMO = 17;
TableroParser.MINIMO = 18;
TableroParser.CONTAR = 19;
TableroParser.BARRAS = 20;
TableroParser.LINEAS = 21;
TableroParser.TORTA = 22;
TableroParser.TABLA = 23;
TableroParser.VERDADERO = 24;
TableroParser.FALSO = 25;
TableroParser.EQ = 26;
TableroParser.NEQ = 27;
TableroParser.GTE = 28;
TableroParser.LTE = 29;
TableroParser.GT = 30;
TableroParser.LT = 31;
TableroParser.ASSIGN = 32;
TableroParser.LBRACE = 33;
TableroParser.RBRACE = 34;
TableroParser.LPAREN = 35;
TableroParser.RPAREN = 36;
TableroParser.SEMICOLON = 37;
TableroParser.DOT = 38;
TableroParser.ID = 39;
TableroParser.NUMBER = 40;
TableroParser.STRING = 41;
TableroParser.WS = 42;
TableroParser.COMMENT = 43;

TableroParser.RULE_programa = 0;
TableroParser.RULE_elemento = 1;
TableroParser.RULE_fuente = 2;
TableroParser.RULE_tipo_fuente = 3;
TableroParser.RULE_metrica = 4;
TableroParser.RULE_agregacion = 5;
TableroParser.RULE_grafico = 6;
TableroParser.RULE_tipo_grafico = 7;
TableroParser.RULE_filtro = 8;
TableroParser.RULE_operador = 9;
TableroParser.RULE_alerta = 10;
TableroParser.RULE_campo = 11;
TableroParser.RULE_valor = 12;
TableroParser.RULE_booleano = 13;
TableroParser.RULE_identificador = 14;
TableroParser.RULE_cadena = 15;
TableroParser.RULE_numero = 16;

class ProgramaContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_programa;
    }

	TABLERO() {
	    return this.getToken(TableroParser.TABLERO, 0);
	};

	identificador() {
	    return this.getTypedRuleContext(IdentificadorContext,0);
	};

	LBRACE() {
	    return this.getToken(TableroParser.LBRACE, 0);
	};

	RBRACE() {
	    return this.getToken(TableroParser.RBRACE, 0);
	};

	SEMICOLON() {
	    return this.getToken(TableroParser.SEMICOLON, 0);
	};

	elemento = function(i) {
	    if(i===undefined) {
	        i = null;
	    }
	    if(i===null) {
	        return this.getTypedRuleContexts(ElementoContext);
	    } else {
	        return this.getTypedRuleContext(ElementoContext,i);
	    }
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterPrograma(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitPrograma(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitPrograma(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class ElementoContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_elemento;
    }

	fuente() {
	    return this.getTypedRuleContext(FuenteContext,0);
	};

	metrica() {
	    return this.getTypedRuleContext(MetricaContext,0);
	};

	grafico() {
	    return this.getTypedRuleContext(GraficoContext,0);
	};

	filtro() {
	    return this.getTypedRuleContext(FiltroContext,0);
	};

	alerta() {
	    return this.getTypedRuleContext(AlertaContext,0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterElemento(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitElemento(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitElemento(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class FuenteContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_fuente;
    }

	FUENTE() {
	    return this.getToken(TableroParser.FUENTE, 0);
	};

	identificador() {
	    return this.getTypedRuleContext(IdentificadorContext,0);
	};

	TIPO() {
	    return this.getToken(TableroParser.TIPO, 0);
	};

	tipo_fuente() {
	    return this.getTypedRuleContext(Tipo_fuenteContext,0);
	};

	RUTA() {
	    return this.getToken(TableroParser.RUTA, 0);
	};

	cadena() {
	    return this.getTypedRuleContext(CadenaContext,0);
	};

	SEMICOLON() {
	    return this.getToken(TableroParser.SEMICOLON, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterFuente(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitFuente(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitFuente(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class Tipo_fuenteContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_tipo_fuente;
    }

	CSV() {
	    return this.getToken(TableroParser.CSV, 0);
	};

	API() {
	    return this.getToken(TableroParser.API, 0);
	};

	JSON_T() {
	    return this.getToken(TableroParser.JSON_T, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterTipo_fuente(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitTipo_fuente(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitTipo_fuente(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class MetricaContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_metrica;
    }

	METRICA() {
	    return this.getToken(TableroParser.METRICA, 0);
	};

	identificador() {
	    return this.getTypedRuleContext(IdentificadorContext,0);
	};

	ASSIGN() {
	    return this.getToken(TableroParser.ASSIGN, 0);
	};

	agregacion() {
	    return this.getTypedRuleContext(AgregacionContext,0);
	};

	LPAREN() {
	    return this.getToken(TableroParser.LPAREN, 0);
	};

	campo() {
	    return this.getTypedRuleContext(CampoContext,0);
	};

	RPAREN() {
	    return this.getToken(TableroParser.RPAREN, 0);
	};

	SEMICOLON() {
	    return this.getToken(TableroParser.SEMICOLON, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterMetrica(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitMetrica(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitMetrica(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class AgregacionContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_agregacion;
    }

	SUMA() {
	    return this.getToken(TableroParser.SUMA, 0);
	};

	PROMEDIO() {
	    return this.getToken(TableroParser.PROMEDIO, 0);
	};

	MAXIMO() {
	    return this.getToken(TableroParser.MAXIMO, 0);
	};

	MINIMO() {
	    return this.getToken(TableroParser.MINIMO, 0);
	};

	CONTAR() {
	    return this.getToken(TableroParser.CONTAR, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterAgregacion(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitAgregacion(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitAgregacion(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class GraficoContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_grafico;
    }

	GRAFICO() {
	    return this.getToken(TableroParser.GRAFICO, 0);
	};

	identificador = function(i) {
	    if(i===undefined) {
	        i = null;
	    }
	    if(i===null) {
	        return this.getTypedRuleContexts(IdentificadorContext);
	    } else {
	        return this.getTypedRuleContext(IdentificadorContext,i);
	    }
	};

	LBRACE() {
	    return this.getToken(TableroParser.LBRACE, 0);
	};

	TIPO() {
	    return this.getToken(TableroParser.TIPO, 0);
	};

	ASSIGN = function(i) {
		if(i===undefined) {
			i = null;
		}
	    if(i===null) {
	        return this.getTokens(TableroParser.ASSIGN);
	    } else {
	        return this.getToken(TableroParser.ASSIGN, i);
	    }
	};


	tipo_grafico() {
	    return this.getTypedRuleContext(Tipo_graficoContext,0);
	};

	SEMICOLON = function(i) {
		if(i===undefined) {
			i = null;
		}
	    if(i===null) {
	        return this.getTokens(TableroParser.SEMICOLON);
	    } else {
	        return this.getToken(TableroParser.SEMICOLON, i);
	    }
	};


	USAR() {
	    return this.getToken(TableroParser.USAR, 0);
	};

	RBRACE() {
	    return this.getToken(TableroParser.RBRACE, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterGrafico(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitGrafico(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitGrafico(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class Tipo_graficoContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_tipo_grafico;
    }

	BARRAS() {
	    return this.getToken(TableroParser.BARRAS, 0);
	};

	LINEAS() {
	    return this.getToken(TableroParser.LINEAS, 0);
	};

	TORTA() {
	    return this.getToken(TableroParser.TORTA, 0);
	};

	TABLA() {
	    return this.getToken(TableroParser.TABLA, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterTipo_grafico(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitTipo_grafico(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitTipo_grafico(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class FiltroContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_filtro;
    }

	FILTRO() {
	    return this.getToken(TableroParser.FILTRO, 0);
	};

	campo() {
	    return this.getTypedRuleContext(CampoContext,0);
	};

	operador() {
	    return this.getTypedRuleContext(OperadorContext,0);
	};

	valor() {
	    return this.getTypedRuleContext(ValorContext,0);
	};

	SEMICOLON() {
	    return this.getToken(TableroParser.SEMICOLON, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterFiltro(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitFiltro(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitFiltro(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class OperadorContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_operador;
    }

	EQ() {
	    return this.getToken(TableroParser.EQ, 0);
	};

	NEQ() {
	    return this.getToken(TableroParser.NEQ, 0);
	};

	GT() {
	    return this.getToken(TableroParser.GT, 0);
	};

	LT() {
	    return this.getToken(TableroParser.LT, 0);
	};

	GTE() {
	    return this.getToken(TableroParser.GTE, 0);
	};

	LTE() {
	    return this.getToken(TableroParser.LTE, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterOperador(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitOperador(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitOperador(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class AlertaContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_alerta;
    }

	ALERTA() {
	    return this.getToken(TableroParser.ALERTA, 0);
	};

	SI() {
	    return this.getToken(TableroParser.SI, 0);
	};

	identificador() {
	    return this.getTypedRuleContext(IdentificadorContext,0);
	};

	operador() {
	    return this.getTypedRuleContext(OperadorContext,0);
	};

	valor() {
	    return this.getTypedRuleContext(ValorContext,0);
	};

	ENTONCES() {
	    return this.getToken(TableroParser.ENTONCES, 0);
	};

	cadena() {
	    return this.getTypedRuleContext(CadenaContext,0);
	};

	SEMICOLON() {
	    return this.getToken(TableroParser.SEMICOLON, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterAlerta(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitAlerta(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitAlerta(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class CampoContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_campo;
    }

	identificador = function(i) {
	    if(i===undefined) {
	        i = null;
	    }
	    if(i===null) {
	        return this.getTypedRuleContexts(IdentificadorContext);
	    } else {
	        return this.getTypedRuleContext(IdentificadorContext,i);
	    }
	};

	DOT = function(i) {
		if(i===undefined) {
			i = null;
		}
	    if(i===null) {
	        return this.getTokens(TableroParser.DOT);
	    } else {
	        return this.getToken(TableroParser.DOT, i);
	    }
	};


	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterCampo(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitCampo(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitCampo(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class ValorContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_valor;
    }

	cadena() {
	    return this.getTypedRuleContext(CadenaContext,0);
	};

	numero() {
	    return this.getTypedRuleContext(NumeroContext,0);
	};

	booleano() {
	    return this.getTypedRuleContext(BooleanoContext,0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterValor(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitValor(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitValor(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class BooleanoContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_booleano;
    }

	VERDADERO() {
	    return this.getToken(TableroParser.VERDADERO, 0);
	};

	FALSO() {
	    return this.getToken(TableroParser.FALSO, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterBooleano(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitBooleano(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitBooleano(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class IdentificadorContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_identificador;
    }

	ID() {
	    return this.getToken(TableroParser.ID, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterIdentificador(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitIdentificador(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitIdentificador(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class CadenaContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_cadena;
    }

	STRING() {
	    return this.getToken(TableroParser.STRING, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterCadena(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitCadena(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitCadena(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class NumeroContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = TableroParser.RULE_numero;
    }

	NUMBER() {
	    return this.getToken(TableroParser.NUMBER, 0);
	};

	enterRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.enterNumero(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof TableroListener ) {
	        listener.exitNumero(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof TableroVisitor ) {
	        return visitor.visitNumero(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}




TableroParser.ProgramaContext = ProgramaContext; 
TableroParser.ElementoContext = ElementoContext; 
TableroParser.FuenteContext = FuenteContext; 
TableroParser.Tipo_fuenteContext = Tipo_fuenteContext; 
TableroParser.MetricaContext = MetricaContext; 
TableroParser.AgregacionContext = AgregacionContext; 
TableroParser.GraficoContext = GraficoContext; 
TableroParser.Tipo_graficoContext = Tipo_graficoContext; 
TableroParser.FiltroContext = FiltroContext; 
TableroParser.OperadorContext = OperadorContext; 
TableroParser.AlertaContext = AlertaContext; 
TableroParser.CampoContext = CampoContext; 
TableroParser.ValorContext = ValorContext; 
TableroParser.BooleanoContext = BooleanoContext; 
TableroParser.IdentificadorContext = IdentificadorContext; 
TableroParser.CadenaContext = CadenaContext; 
TableroParser.NumeroContext = NumeroContext; 
