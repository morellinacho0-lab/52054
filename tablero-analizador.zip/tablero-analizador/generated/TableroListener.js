// Generated from java-escape by ANTLR 4.11.1
// jshint ignore: start
import antlr4 from 'antlr4';

// This class defines a complete listener for a parse tree produced by TableroParser.
export default class TableroListener extends antlr4.tree.ParseTreeListener {

	// Enter a parse tree produced by TableroParser#programa.
	enterPrograma(ctx) {
	}

	// Exit a parse tree produced by TableroParser#programa.
	exitPrograma(ctx) {
	}


	// Enter a parse tree produced by TableroParser#elemento.
	enterElemento(ctx) {
	}

	// Exit a parse tree produced by TableroParser#elemento.
	exitElemento(ctx) {
	}


	// Enter a parse tree produced by TableroParser#fuente.
	enterFuente(ctx) {
	}

	// Exit a parse tree produced by TableroParser#fuente.
	exitFuente(ctx) {
	}


	// Enter a parse tree produced by TableroParser#tipo_fuente.
	enterTipo_fuente(ctx) {
	}

	// Exit a parse tree produced by TableroParser#tipo_fuente.
	exitTipo_fuente(ctx) {
	}


	// Enter a parse tree produced by TableroParser#metrica.
	enterMetrica(ctx) {
	}

	// Exit a parse tree produced by TableroParser#metrica.
	exitMetrica(ctx) {
	}


	// Enter a parse tree produced by TableroParser#agregacion.
	enterAgregacion(ctx) {
	}

	// Exit a parse tree produced by TableroParser#agregacion.
	exitAgregacion(ctx) {
	}


	// Enter a parse tree produced by TableroParser#grafico.
	enterGrafico(ctx) {
	}

	// Exit a parse tree produced by TableroParser#grafico.
	exitGrafico(ctx) {
	}


	// Enter a parse tree produced by TableroParser#tipo_grafico.
	enterTipo_grafico(ctx) {
	}

	// Exit a parse tree produced by TableroParser#tipo_grafico.
	exitTipo_grafico(ctx) {
	}


	// Enter a parse tree produced by TableroParser#filtro.
	enterFiltro(ctx) {
	}

	// Exit a parse tree produced by TableroParser#filtro.
	exitFiltro(ctx) {
	}


	// Enter a parse tree produced by TableroParser#operador.
	enterOperador(ctx) {
	}

	// Exit a parse tree produced by TableroParser#operador.
	exitOperador(ctx) {
	}


	// Enter a parse tree produced by TableroParser#alerta.
	enterAlerta(ctx) {
	}

	// Exit a parse tree produced by TableroParser#alerta.
	exitAlerta(ctx) {
	}


	// Enter a parse tree produced by TableroParser#campo.
	enterCampo(ctx) {
	}

	// Exit a parse tree produced by TableroParser#campo.
	exitCampo(ctx) {
	}


	// Enter a parse tree produced by TableroParser#valor.
	enterValor(ctx) {
	}

	// Exit a parse tree produced by TableroParser#valor.
	exitValor(ctx) {
	}


	// Enter a parse tree produced by TableroParser#booleano.
	enterBooleano(ctx) {
	}

	// Exit a parse tree produced by TableroParser#booleano.
	exitBooleano(ctx) {
	}


	// Enter a parse tree produced by TableroParser#identificador.
	enterIdentificador(ctx) {
	}

	// Exit a parse tree produced by TableroParser#identificador.
	exitIdentificador(ctx) {
	}


	// Enter a parse tree produced by TableroParser#cadena.
	enterCadena(ctx) {
	}

	// Exit a parse tree produced by TableroParser#cadena.
	exitCadena(ctx) {
	}


	// Enter a parse tree produced by TableroParser#numero.
	enterNumero(ctx) {
	}

	// Exit a parse tree produced by TableroParser#numero.
	exitNumero(ctx) {
	}



}