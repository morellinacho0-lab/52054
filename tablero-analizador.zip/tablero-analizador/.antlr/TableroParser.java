// Generated from e:/Descargas/INGENIERÍA EN SISTEMAS/Sintaxisy Semántica de los lenguajes/Unidad 4/Analizador/tablero-analizador/Tablero.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class TableroParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		TABLERO=1, FUENTE=2, TIPO=3, RUTA=4, METRICA=5, GRAFICO=6, USAR=7, FILTRO=8, 
		ALERTA=9, SI=10, ENTONCES=11, CSV=12, API=13, JSON_T=14, SUMA=15, PROMEDIO=16, 
		MAXIMO=17, MINIMO=18, CONTAR=19, BARRAS=20, LINEAS=21, TORTA=22, TABLA=23, 
		VERDADERO=24, FALSO=25, EQ=26, NEQ=27, GTE=28, LTE=29, GT=30, LT=31, ASSIGN=32, 
		LBRACE=33, RBRACE=34, LPAREN=35, RPAREN=36, SEMICOLON=37, DOT=38, ID=39, 
		NUMBER=40, STRING=41, WS=42, COMMENT=43;
	public static final int
		RULE_programa = 0, RULE_elemento = 1, RULE_fuente = 2, RULE_tipo_fuente = 3, 
		RULE_metrica = 4, RULE_agregacion = 5, RULE_grafico = 6, RULE_tipo_grafico = 7, 
		RULE_filtro = 8, RULE_operador = 9, RULE_alerta = 10, RULE_campo = 11, 
		RULE_valor = 12, RULE_booleano = 13, RULE_identificador = 14, RULE_cadena = 15, 
		RULE_numero = 16;
	private static String[] makeRuleNames() {
		return new String[] {
			"programa", "elemento", "fuente", "tipo_fuente", "metrica", "agregacion", 
			"grafico", "tipo_grafico", "filtro", "operador", "alerta", "campo", "valor", 
			"booleano", "identificador", "cadena", "numero"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'tablero'", "'fuente'", "'tipo'", "'ruta'", "'metrica'", "'grafico'", 
			"'usar'", "'filtro'", "'alerta'", "'si'", "'entonces'", "'csv'", "'api'", 
			"'json'", "'suma'", "'promedio'", "'maximo'", "'minimo'", "'contar'", 
			"'barras'", "'lineas'", "'torta'", "'tabla'", "'verdadero'", "'falso'", 
			"'=='", "'!='", "'>='", "'<='", "'>'", "'<'", "'='", "'{'", "'}'", "'('", 
			"')'", "';'", "'.'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "TABLERO", "FUENTE", "TIPO", "RUTA", "METRICA", "GRAFICO", "USAR", 
			"FILTRO", "ALERTA", "SI", "ENTONCES", "CSV", "API", "JSON_T", "SUMA", 
			"PROMEDIO", "MAXIMO", "MINIMO", "CONTAR", "BARRAS", "LINEAS", "TORTA", 
			"TABLA", "VERDADERO", "FALSO", "EQ", "NEQ", "GTE", "LTE", "GT", "LT", 
			"ASSIGN", "LBRACE", "RBRACE", "LPAREN", "RPAREN", "SEMICOLON", "DOT", 
			"ID", "NUMBER", "STRING", "WS", "COMMENT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Tablero.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public TableroParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgramaContext extends ParserRuleContext {
		public TerminalNode TABLERO() { return getToken(TableroParser.TABLERO, 0); }
		public IdentificadorContext identificador() {
			return getRuleContext(IdentificadorContext.class,0);
		}
		public TerminalNode LBRACE() { return getToken(TableroParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(TableroParser.RBRACE, 0); }
		public TerminalNode SEMICOLON() { return getToken(TableroParser.SEMICOLON, 0); }
		public List<ElementoContext> elemento() {
			return getRuleContexts(ElementoContext.class);
		}
		public ElementoContext elemento(int i) {
			return getRuleContext(ElementoContext.class,i);
		}
		public ProgramaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_programa; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterPrograma(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitPrograma(this);
		}
	}

	public final ProgramaContext programa() throws RecognitionException {
		ProgramaContext _localctx = new ProgramaContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_programa);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(34);
			match(TABLERO);
			setState(35);
			identificador();
			setState(36);
			match(LBRACE);
			setState(40);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 868L) != 0)) {
				{
				{
				setState(37);
				elemento();
				}
				}
				setState(42);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(43);
			match(RBRACE);
			setState(44);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ElementoContext extends ParserRuleContext {
		public FuenteContext fuente() {
			return getRuleContext(FuenteContext.class,0);
		}
		public MetricaContext metrica() {
			return getRuleContext(MetricaContext.class,0);
		}
		public GraficoContext grafico() {
			return getRuleContext(GraficoContext.class,0);
		}
		public FiltroContext filtro() {
			return getRuleContext(FiltroContext.class,0);
		}
		public AlertaContext alerta() {
			return getRuleContext(AlertaContext.class,0);
		}
		public ElementoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elemento; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterElemento(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitElemento(this);
		}
	}

	public final ElementoContext elemento() throws RecognitionException {
		ElementoContext _localctx = new ElementoContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_elemento);
		try {
			setState(51);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case FUENTE:
				enterOuterAlt(_localctx, 1);
				{
				setState(46);
				fuente();
				}
				break;
			case METRICA:
				enterOuterAlt(_localctx, 2);
				{
				setState(47);
				metrica();
				}
				break;
			case GRAFICO:
				enterOuterAlt(_localctx, 3);
				{
				setState(48);
				grafico();
				}
				break;
			case FILTRO:
				enterOuterAlt(_localctx, 4);
				{
				setState(49);
				filtro();
				}
				break;
			case ALERTA:
				enterOuterAlt(_localctx, 5);
				{
				setState(50);
				alerta();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FuenteContext extends ParserRuleContext {
		public TerminalNode FUENTE() { return getToken(TableroParser.FUENTE, 0); }
		public IdentificadorContext identificador() {
			return getRuleContext(IdentificadorContext.class,0);
		}
		public TerminalNode TIPO() { return getToken(TableroParser.TIPO, 0); }
		public Tipo_fuenteContext tipo_fuente() {
			return getRuleContext(Tipo_fuenteContext.class,0);
		}
		public TerminalNode RUTA() { return getToken(TableroParser.RUTA, 0); }
		public CadenaContext cadena() {
			return getRuleContext(CadenaContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(TableroParser.SEMICOLON, 0); }
		public FuenteContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fuente; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterFuente(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitFuente(this);
		}
	}

	public final FuenteContext fuente() throws RecognitionException {
		FuenteContext _localctx = new FuenteContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_fuente);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(53);
			match(FUENTE);
			setState(54);
			identificador();
			setState(55);
			match(TIPO);
			setState(56);
			tipo_fuente();
			setState(57);
			match(RUTA);
			setState(58);
			cadena();
			setState(59);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Tipo_fuenteContext extends ParserRuleContext {
		public TerminalNode CSV() { return getToken(TableroParser.CSV, 0); }
		public TerminalNode API() { return getToken(TableroParser.API, 0); }
		public TerminalNode JSON_T() { return getToken(TableroParser.JSON_T, 0); }
		public Tipo_fuenteContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tipo_fuente; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterTipo_fuente(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitTipo_fuente(this);
		}
	}

	public final Tipo_fuenteContext tipo_fuente() throws RecognitionException {
		Tipo_fuenteContext _localctx = new Tipo_fuenteContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_tipo_fuente);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(61);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 28672L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MetricaContext extends ParserRuleContext {
		public TerminalNode METRICA() { return getToken(TableroParser.METRICA, 0); }
		public IdentificadorContext identificador() {
			return getRuleContext(IdentificadorContext.class,0);
		}
		public TerminalNode ASSIGN() { return getToken(TableroParser.ASSIGN, 0); }
		public AgregacionContext agregacion() {
			return getRuleContext(AgregacionContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(TableroParser.LPAREN, 0); }
		public CampoContext campo() {
			return getRuleContext(CampoContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(TableroParser.RPAREN, 0); }
		public TerminalNode SEMICOLON() { return getToken(TableroParser.SEMICOLON, 0); }
		public MetricaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_metrica; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterMetrica(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitMetrica(this);
		}
	}

	public final MetricaContext metrica() throws RecognitionException {
		MetricaContext _localctx = new MetricaContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_metrica);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(63);
			match(METRICA);
			setState(64);
			identificador();
			setState(65);
			match(ASSIGN);
			setState(66);
			agregacion();
			setState(67);
			match(LPAREN);
			setState(68);
			campo();
			setState(69);
			match(RPAREN);
			setState(70);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AgregacionContext extends ParserRuleContext {
		public TerminalNode SUMA() { return getToken(TableroParser.SUMA, 0); }
		public TerminalNode PROMEDIO() { return getToken(TableroParser.PROMEDIO, 0); }
		public TerminalNode MAXIMO() { return getToken(TableroParser.MAXIMO, 0); }
		public TerminalNode MINIMO() { return getToken(TableroParser.MINIMO, 0); }
		public TerminalNode CONTAR() { return getToken(TableroParser.CONTAR, 0); }
		public AgregacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_agregacion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterAgregacion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitAgregacion(this);
		}
	}

	public final AgregacionContext agregacion() throws RecognitionException {
		AgregacionContext _localctx = new AgregacionContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_agregacion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(72);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 1015808L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GraficoContext extends ParserRuleContext {
		public TerminalNode GRAFICO() { return getToken(TableroParser.GRAFICO, 0); }
		public List<IdentificadorContext> identificador() {
			return getRuleContexts(IdentificadorContext.class);
		}
		public IdentificadorContext identificador(int i) {
			return getRuleContext(IdentificadorContext.class,i);
		}
		public TerminalNode LBRACE() { return getToken(TableroParser.LBRACE, 0); }
		public TerminalNode TIPO() { return getToken(TableroParser.TIPO, 0); }
		public List<TerminalNode> ASSIGN() { return getTokens(TableroParser.ASSIGN); }
		public TerminalNode ASSIGN(int i) {
			return getToken(TableroParser.ASSIGN, i);
		}
		public Tipo_graficoContext tipo_grafico() {
			return getRuleContext(Tipo_graficoContext.class,0);
		}
		public List<TerminalNode> SEMICOLON() { return getTokens(TableroParser.SEMICOLON); }
		public TerminalNode SEMICOLON(int i) {
			return getToken(TableroParser.SEMICOLON, i);
		}
		public TerminalNode USAR() { return getToken(TableroParser.USAR, 0); }
		public TerminalNode RBRACE() { return getToken(TableroParser.RBRACE, 0); }
		public GraficoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_grafico; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterGrafico(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitGrafico(this);
		}
	}

	public final GraficoContext grafico() throws RecognitionException {
		GraficoContext _localctx = new GraficoContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_grafico);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(74);
			match(GRAFICO);
			setState(75);
			identificador();
			setState(76);
			match(LBRACE);
			setState(77);
			match(TIPO);
			setState(78);
			match(ASSIGN);
			setState(79);
			tipo_grafico();
			setState(80);
			match(SEMICOLON);
			setState(81);
			match(USAR);
			setState(82);
			match(ASSIGN);
			setState(83);
			identificador();
			setState(84);
			match(SEMICOLON);
			setState(85);
			match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Tipo_graficoContext extends ParserRuleContext {
		public TerminalNode BARRAS() { return getToken(TableroParser.BARRAS, 0); }
		public TerminalNode LINEAS() { return getToken(TableroParser.LINEAS, 0); }
		public TerminalNode TORTA() { return getToken(TableroParser.TORTA, 0); }
		public TerminalNode TABLA() { return getToken(TableroParser.TABLA, 0); }
		public Tipo_graficoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tipo_grafico; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterTipo_grafico(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitTipo_grafico(this);
		}
	}

	public final Tipo_graficoContext tipo_grafico() throws RecognitionException {
		Tipo_graficoContext _localctx = new Tipo_graficoContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_tipo_grafico);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(87);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 15728640L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FiltroContext extends ParserRuleContext {
		public TerminalNode FILTRO() { return getToken(TableroParser.FILTRO, 0); }
		public CampoContext campo() {
			return getRuleContext(CampoContext.class,0);
		}
		public OperadorContext operador() {
			return getRuleContext(OperadorContext.class,0);
		}
		public ValorContext valor() {
			return getRuleContext(ValorContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(TableroParser.SEMICOLON, 0); }
		public FiltroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_filtro; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterFiltro(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitFiltro(this);
		}
	}

	public final FiltroContext filtro() throws RecognitionException {
		FiltroContext _localctx = new FiltroContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_filtro);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(89);
			match(FILTRO);
			setState(90);
			campo();
			setState(91);
			operador();
			setState(92);
			valor();
			setState(93);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OperadorContext extends ParserRuleContext {
		public TerminalNode EQ() { return getToken(TableroParser.EQ, 0); }
		public TerminalNode NEQ() { return getToken(TableroParser.NEQ, 0); }
		public TerminalNode GT() { return getToken(TableroParser.GT, 0); }
		public TerminalNode LT() { return getToken(TableroParser.LT, 0); }
		public TerminalNode GTE() { return getToken(TableroParser.GTE, 0); }
		public TerminalNode LTE() { return getToken(TableroParser.LTE, 0); }
		public OperadorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operador; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterOperador(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitOperador(this);
		}
	}

	public final OperadorContext operador() throws RecognitionException {
		OperadorContext _localctx = new OperadorContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_operador);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(95);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 4227858432L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AlertaContext extends ParserRuleContext {
		public TerminalNode ALERTA() { return getToken(TableroParser.ALERTA, 0); }
		public TerminalNode SI() { return getToken(TableroParser.SI, 0); }
		public IdentificadorContext identificador() {
			return getRuleContext(IdentificadorContext.class,0);
		}
		public OperadorContext operador() {
			return getRuleContext(OperadorContext.class,0);
		}
		public ValorContext valor() {
			return getRuleContext(ValorContext.class,0);
		}
		public TerminalNode ENTONCES() { return getToken(TableroParser.ENTONCES, 0); }
		public CadenaContext cadena() {
			return getRuleContext(CadenaContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(TableroParser.SEMICOLON, 0); }
		public AlertaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alerta; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterAlerta(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitAlerta(this);
		}
	}

	public final AlertaContext alerta() throws RecognitionException {
		AlertaContext _localctx = new AlertaContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_alerta);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(97);
			match(ALERTA);
			setState(98);
			match(SI);
			setState(99);
			identificador();
			setState(100);
			operador();
			setState(101);
			valor();
			setState(102);
			match(ENTONCES);
			setState(103);
			cadena();
			setState(104);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CampoContext extends ParserRuleContext {
		public List<IdentificadorContext> identificador() {
			return getRuleContexts(IdentificadorContext.class);
		}
		public IdentificadorContext identificador(int i) {
			return getRuleContext(IdentificadorContext.class,i);
		}
		public List<TerminalNode> DOT() { return getTokens(TableroParser.DOT); }
		public TerminalNode DOT(int i) {
			return getToken(TableroParser.DOT, i);
		}
		public CampoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_campo; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterCampo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitCampo(this);
		}
	}

	public final CampoContext campo() throws RecognitionException {
		CampoContext _localctx = new CampoContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_campo);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(106);
			identificador();
			setState(111);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==DOT) {
				{
				{
				setState(107);
				match(DOT);
				setState(108);
				identificador();
				}
				}
				setState(113);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValorContext extends ParserRuleContext {
		public CadenaContext cadena() {
			return getRuleContext(CadenaContext.class,0);
		}
		public NumeroContext numero() {
			return getRuleContext(NumeroContext.class,0);
		}
		public BooleanoContext booleano() {
			return getRuleContext(BooleanoContext.class,0);
		}
		public ValorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_valor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterValor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitValor(this);
		}
	}

	public final ValorContext valor() throws RecognitionException {
		ValorContext _localctx = new ValorContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_valor);
		try {
			setState(117);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRING:
				enterOuterAlt(_localctx, 1);
				{
				setState(114);
				cadena();
				}
				break;
			case NUMBER:
				enterOuterAlt(_localctx, 2);
				{
				setState(115);
				numero();
				}
				break;
			case VERDADERO:
			case FALSO:
				enterOuterAlt(_localctx, 3);
				{
				setState(116);
				booleano();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BooleanoContext extends ParserRuleContext {
		public TerminalNode VERDADERO() { return getToken(TableroParser.VERDADERO, 0); }
		public TerminalNode FALSO() { return getToken(TableroParser.FALSO, 0); }
		public BooleanoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_booleano; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterBooleano(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitBooleano(this);
		}
	}

	public final BooleanoContext booleano() throws RecognitionException {
		BooleanoContext _localctx = new BooleanoContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_booleano);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(119);
			_la = _input.LA(1);
			if ( !(_la==VERDADERO || _la==FALSO) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IdentificadorContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(TableroParser.ID, 0); }
		public IdentificadorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identificador; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterIdentificador(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitIdentificador(this);
		}
	}

	public final IdentificadorContext identificador() throws RecognitionException {
		IdentificadorContext _localctx = new IdentificadorContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_identificador);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(121);
			match(ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CadenaContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(TableroParser.STRING, 0); }
		public CadenaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cadena; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterCadena(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitCadena(this);
		}
	}

	public final CadenaContext cadena() throws RecognitionException {
		CadenaContext _localctx = new CadenaContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_cadena);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(123);
			match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumeroContext extends ParserRuleContext {
		public TerminalNode NUMBER() { return getToken(TableroParser.NUMBER, 0); }
		public NumeroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numero; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).enterNumero(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TableroListener ) ((TableroListener)listener).exitNumero(this);
		}
	}

	public final NumeroContext numero() throws RecognitionException {
		NumeroContext _localctx = new NumeroContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_numero);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(125);
			match(NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001+\u0080\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000"+
		"\u0005\u0000\'\b\u0000\n\u0000\f\u0000*\t\u0000\u0001\u0000\u0001\u0000"+
		"\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0003\u00014\b\u0001\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0003\u0001\u0003"+
		"\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004"+
		"\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0005\u0001\u0005\u0001\u0006"+
		"\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0007\u0001\u0007\u0001\b\u0001\b\u0001\b\u0001\b\u0001\b\u0001"+
		"\b\u0001\t\u0001\t\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001"+
		"\n\u0001\n\u0001\n\u0001\u000b\u0001\u000b\u0001\u000b\u0005\u000bn\b"+
		"\u000b\n\u000b\f\u000bq\t\u000b\u0001\f\u0001\f\u0001\f\u0003\fv\b\f\u0001"+
		"\r\u0001\r\u0001\u000e\u0001\u000e\u0001\u000f\u0001\u000f\u0001\u0010"+
		"\u0001\u0010\u0001\u0010\u0000\u0000\u0011\u0000\u0002\u0004\u0006\b\n"+
		"\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \u0000\u0005"+
		"\u0001\u0000\f\u000e\u0001\u0000\u000f\u0013\u0001\u0000\u0014\u0017\u0001"+
		"\u0000\u001a\u001f\u0001\u0000\u0018\u0019v\u0000\"\u0001\u0000\u0000"+
		"\u0000\u00023\u0001\u0000\u0000\u0000\u00045\u0001\u0000\u0000\u0000\u0006"+
		"=\u0001\u0000\u0000\u0000\b?\u0001\u0000\u0000\u0000\nH\u0001\u0000\u0000"+
		"\u0000\fJ\u0001\u0000\u0000\u0000\u000eW\u0001\u0000\u0000\u0000\u0010"+
		"Y\u0001\u0000\u0000\u0000\u0012_\u0001\u0000\u0000\u0000\u0014a\u0001"+
		"\u0000\u0000\u0000\u0016j\u0001\u0000\u0000\u0000\u0018u\u0001\u0000\u0000"+
		"\u0000\u001aw\u0001\u0000\u0000\u0000\u001cy\u0001\u0000\u0000\u0000\u001e"+
		"{\u0001\u0000\u0000\u0000 }\u0001\u0000\u0000\u0000\"#\u0005\u0001\u0000"+
		"\u0000#$\u0003\u001c\u000e\u0000$(\u0005!\u0000\u0000%\'\u0003\u0002\u0001"+
		"\u0000&%\u0001\u0000\u0000\u0000\'*\u0001\u0000\u0000\u0000(&\u0001\u0000"+
		"\u0000\u0000()\u0001\u0000\u0000\u0000)+\u0001\u0000\u0000\u0000*(\u0001"+
		"\u0000\u0000\u0000+,\u0005\"\u0000\u0000,-\u0005%\u0000\u0000-\u0001\u0001"+
		"\u0000\u0000\u0000.4\u0003\u0004\u0002\u0000/4\u0003\b\u0004\u000004\u0003"+
		"\f\u0006\u000014\u0003\u0010\b\u000024\u0003\u0014\n\u00003.\u0001\u0000"+
		"\u0000\u00003/\u0001\u0000\u0000\u000030\u0001\u0000\u0000\u000031\u0001"+
		"\u0000\u0000\u000032\u0001\u0000\u0000\u00004\u0003\u0001\u0000\u0000"+
		"\u000056\u0005\u0002\u0000\u000067\u0003\u001c\u000e\u000078\u0005\u0003"+
		"\u0000\u000089\u0003\u0006\u0003\u00009:\u0005\u0004\u0000\u0000:;\u0003"+
		"\u001e\u000f\u0000;<\u0005%\u0000\u0000<\u0005\u0001\u0000\u0000\u0000"+
		"=>\u0007\u0000\u0000\u0000>\u0007\u0001\u0000\u0000\u0000?@\u0005\u0005"+
		"\u0000\u0000@A\u0003\u001c\u000e\u0000AB\u0005 \u0000\u0000BC\u0003\n"+
		"\u0005\u0000CD\u0005#\u0000\u0000DE\u0003\u0016\u000b\u0000EF\u0005$\u0000"+
		"\u0000FG\u0005%\u0000\u0000G\t\u0001\u0000\u0000\u0000HI\u0007\u0001\u0000"+
		"\u0000I\u000b\u0001\u0000\u0000\u0000JK\u0005\u0006\u0000\u0000KL\u0003"+
		"\u001c\u000e\u0000LM\u0005!\u0000\u0000MN\u0005\u0003\u0000\u0000NO\u0005"+
		" \u0000\u0000OP\u0003\u000e\u0007\u0000PQ\u0005%\u0000\u0000QR\u0005\u0007"+
		"\u0000\u0000RS\u0005 \u0000\u0000ST\u0003\u001c\u000e\u0000TU\u0005%\u0000"+
		"\u0000UV\u0005\"\u0000\u0000V\r\u0001\u0000\u0000\u0000WX\u0007\u0002"+
		"\u0000\u0000X\u000f\u0001\u0000\u0000\u0000YZ\u0005\b\u0000\u0000Z[\u0003"+
		"\u0016\u000b\u0000[\\\u0003\u0012\t\u0000\\]\u0003\u0018\f\u0000]^\u0005"+
		"%\u0000\u0000^\u0011\u0001\u0000\u0000\u0000_`\u0007\u0003\u0000\u0000"+
		"`\u0013\u0001\u0000\u0000\u0000ab\u0005\t\u0000\u0000bc\u0005\n\u0000"+
		"\u0000cd\u0003\u001c\u000e\u0000de\u0003\u0012\t\u0000ef\u0003\u0018\f"+
		"\u0000fg\u0005\u000b\u0000\u0000gh\u0003\u001e\u000f\u0000hi\u0005%\u0000"+
		"\u0000i\u0015\u0001\u0000\u0000\u0000jo\u0003\u001c\u000e\u0000kl\u0005"+
		"&\u0000\u0000ln\u0003\u001c\u000e\u0000mk\u0001\u0000\u0000\u0000nq\u0001"+
		"\u0000\u0000\u0000om\u0001\u0000\u0000\u0000op\u0001\u0000\u0000\u0000"+
		"p\u0017\u0001\u0000\u0000\u0000qo\u0001\u0000\u0000\u0000rv\u0003\u001e"+
		"\u000f\u0000sv\u0003 \u0010\u0000tv\u0003\u001a\r\u0000ur\u0001\u0000"+
		"\u0000\u0000us\u0001\u0000\u0000\u0000ut\u0001\u0000\u0000\u0000v\u0019"+
		"\u0001\u0000\u0000\u0000wx\u0007\u0004\u0000\u0000x\u001b\u0001\u0000"+
		"\u0000\u0000yz\u0005\'\u0000\u0000z\u001d\u0001\u0000\u0000\u0000{|\u0005"+
		")\u0000\u0000|\u001f\u0001\u0000\u0000\u0000}~\u0005(\u0000\u0000~!\u0001"+
		"\u0000\u0000\u0000\u0004(3ou";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}