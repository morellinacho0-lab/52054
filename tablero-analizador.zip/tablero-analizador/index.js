// jshint ignore: start
import antlr4 from './node_modules/antlr4/src/antlr4/index.js';
import TableroLexer from './generated/TableroLexer.js';
import TableroParser from './generated/TableroParser.js';
import CustomTableroVisitor from './CustomTableroVisitor.js';
import fs from 'fs';
import { createInterface } from 'readline';

const { CharStreams, CommonTokenStream } = antlr4;

// ============================================================
// COLORES PARA CONSOLA
// ============================================================
const C = {
    reset:  '\x1b[0m',
    bold:   '\x1b[1m',
    red:    '\x1b[31m',
    green:  '\x1b[32m',
    yellow: '\x1b[33m',
    cyan:   '\x1b[36m',
    blue:   '\x1b[34m',
    magenta:'\x1b[35m',
    gray:   '\x1b[90m',
};

function color(c, txt) { return `${c}${txt}${C.reset}`; }

// ============================================================
// LEER ENTRADA DESDE CONSOLA
// ============================================================
async function leerEntradaConsola() {
    const rl = createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(resolve => {
        console.log(color(C.cyan, 'Ingrese el código Tablero (termine con una línea que contenga solo "FIN"):'));
        const lineas = [];
        rl.on('line', line => {
            if (line.trim() === 'FIN') { rl.close(); resolve(lineas.join('\n')); }
            else lineas.push(line);
        });
    });
}

// ============================================================
// IMPRIMIR ÁRBOL EN FORMATO TEXTO (indentado)
// ============================================================
function imprimirArbol(tree, parser, indent = 0) {
    const prefix = '  '.repeat(indent);
    if (tree.getChildCount() === 0) {
        // Nodo hoja (token)
        const txt = tree.getText ? tree.getText() : String(tree);
        return `${prefix}${color(C.yellow, `"${txt}"`)}\n`;
    }
    const ruleName = parser.ruleNames[tree.ruleIndex] ?? 'desconocido';
    let resultado = `${prefix}${color(C.cyan, ruleName)}\n`;
    for (let i = 0; i < tree.getChildCount(); i++) {
        resultado += imprimirArbol(tree.getChild(i), parser, indent + 1);
    }
    return resultado;
}

// ============================================================
// OBTENER NOMBRE DE TOKEN
// ============================================================
function nombreToken(tipo, lexer) {
    if (tipo === -1) return 'EOF';
    return TableroLexer.symbolicNames[tipo] ?? `TOKEN_${tipo}`;
}

// ============================================================
// IMPRIMIR TABLA DE LEXEMAS-TOKENS
// ============================================================
function imprimirTablaTokens(tokens, lexer) {
    const ancho = [20, 20, 8, 8];
    const sep = () => '+' + ancho.map(a => '-'.repeat(a+2)).join('+') + '+';
    const fila = (cols) => '| ' + cols.map((c, i) => String(c).padEnd(ancho[i])).join(' | ') + ' |';

    const lineas = [];
    lineas.push(color(C.bold, '\n╔══════════════════════════════════════════════════════╗'));
    lineas.push(color(C.bold, '║           TABLA DE LEXEMAS - TOKENS                  ║'));
    lineas.push(color(C.bold, '╚══════════════════════════════════════════════════════╝'));
    lineas.push(sep());
    lineas.push(fila(['LEXEMA', 'TOKEN', 'LÍNEA', 'COLUMNA']));
    lineas.push(sep());

    for (const tok of tokens) {
        if (tok.type === -1) continue; // EOF
        const lexema = tok.text ?? '';
        const token  = nombreToken(tok.type, lexer);
        lineas.push(fila([lexema, token, tok.line, tok.column]));
    }
    lineas.push(sep());
    return lineas.join('\n');
}

// ============================================================
// CLASE RECOLECTOR DE ERRORES
// ============================================================
class ErrorRecolector extends antlr4.error.ErrorListener {
    constructor() {
        super();
        this.errores = [];
    }
    syntaxError(recognizer, offendingSymbol, line, column, msg, e) {
        this.errores.push({ line, column, msg, symbol: offendingSymbol?.text ?? '?' });
    }
}

// ============================================================
// FUNCIÓN PRINCIPAL
// ============================================================
async function main() {
    console.log(color(C.bold + C.blue, '\n╔══════════════════════════════════════════════════════════╗'));
    console.log(color(C.bold + C.blue, '║       ANALIZADOR DEL LENGUAJE TABLERO                    ║'));
    console.log(color(C.bold + C.blue, '║       SSL - Sintaxis y Semántica de LP - UTN FRM         ║'));
    console.log(color(C.bold + C.blue, '╚══════════════════════════════════════════════════════════╝'));

    // ── 1. LEER ENTRADA ──────────────────────────────────────
    let input;
    const archivoArg = process.argv[2];

    if (archivoArg) {
        try {
            input = fs.readFileSync(archivoArg, 'utf8');
            console.log(color(C.green, `\n[✓] Entrada leída desde: ${archivoArg}`));
        } catch (e) {
            console.error(color(C.red, `[✗] No se pudo leer el archivo: ${archivoArg}`));
            process.exit(1);
        }
    } else {
        try {
            input = fs.readFileSync('input.txt', 'utf8');
            console.log(color(C.green, '\n[✓] Entrada leída desde: input.txt'));
        } catch (e) {
            input = await leerEntradaConsola();
        }
    }

    console.log(color(C.gray, '\n── Código fuente de entrada ─────────────────────────────'));
    const lineasCodigo = input.split('\n');
    lineasCodigo.forEach((l, i) => console.log(color(C.gray, `  ${String(i+1).padStart(3)}: ${l}`)));
    console.log(color(C.gray, '─────────────────────────────────────────────────────────'));

    // ── 2. ANÁLISIS LÉXICO ───────────────────────────────────
    console.log(color(C.bold, '\n[1] ANÁLISIS LÉXICO'));
    const inputStream = CharStreams.fromString(input);
    const lexer = new TableroLexer(inputStream);
    const errorLexer = new ErrorRecolector();
    lexer.removeErrorListeners();
    lexer.addErrorListener(errorLexer);

    const tokenStream = new CommonTokenStream(lexer);
    tokenStream.fill();
    const todosTokens = tokenStream.tokens;

    if (errorLexer.errores.length > 0) {
        console.log(color(C.red, '\n[✗] Errores léxicos encontrados:'));
        for (const e of errorLexer.errores) {
            console.log(color(C.red, `    Línea ${e.line}, col ${e.column}: ${e.msg}`));
        }
    } else {
        console.log(color(C.green, `    [✓] Análisis léxico exitoso. ${todosTokens.length - 1} tokens reconocidos.`));
    }

    // ── 3. TABLA DE LEXEMAS-TOKENS ───────────────────────────
    console.log(imprimirTablaTokens(todosTokens, lexer));

    // ── 4. ANÁLISIS SINTÁCTICO ───────────────────────────────
    console.log(color(C.bold, '\n[2] ANÁLISIS SINTÁCTICO'));
    const inputStream2 = CharStreams.fromString(input);
    const lexer2 = new TableroLexer(inputStream2);
    lexer2.removeErrorListeners();
    const tokenStream2 = new CommonTokenStream(lexer2);
    const parser = new TableroParser(tokenStream2);

    const errorParser = new ErrorRecolector();
    parser.removeErrorListeners();
    parser.addErrorListener(errorParser);

    const tree = parser.programa();

    if (errorParser.errores.length > 0) {
        console.log(color(C.red, '\n[✗] Errores sintácticos encontrados:'));
        for (const e of errorParser.errores) {
            console.log(color(C.red, `    Línea ${e.line}, col ${e.column}: ${e.msg} (símbolo: '${e.symbol}')`));
        }
        console.log(color(C.red, '\n[✗] Análisis terminado con errores. No se puede continuar.'));
        process.exit(1);
    }

    console.log(color(C.green, '    [✓] Análisis sintáctico exitoso. La entrada es válida.'));

    // ── 5. ÁRBOL DE ANÁLISIS SINTÁCTICO ─────────────────────
    console.log(color(C.bold, '\n[3] ÁRBOL DE ANÁLISIS SINTÁCTICO'));
    console.log(color(C.gray, '    (Formato texto estructurado)\n'));

    // Formato lineal (compatible ANTLR estándar)
    const arbolLineal = tree.toStringTree(parser.ruleNames);
    console.log(color(C.gray, '    Representación ANTLR: ') + arbolLineal);

    // Formato indentado (legible)
    console.log(color(C.cyan, '\n    Representación indentada:\n'));
    console.log(imprimirArbol(tree, parser, 2));

    // ── 6. ANÁLISIS SEMÁNTICO + TRADUCCIÓN ──────────────────
    console.log(color(C.bold, '[4] ANÁLISIS SEMÁNTICO E INTERPRETACIÓN (Traducción a JavaScript)'));

    const visitor = new CustomTableroVisitor();
    visitor.visit(tree);

    // Mostrar advertencias semánticas
    if (visitor.erroresSemanticos.length > 0) {
        console.log(color(C.yellow, '\n    Advertencias semánticas:'));
        for (const adv of visitor.erroresSemanticos) {
            console.log(color(C.yellow, `    ⚠ ${adv}`));
        }
    } else {
        console.log(color(C.green, '    [✓] Sin errores semánticos detectados.'));
    }

    // Mostrar código JS generado
    const codigoJS = visitor.jsLines.join('\n');
    console.log(color(C.bold, '\n    ── Código JavaScript generado ────────────────────────'));
    const lineasJS = codigoJS.split('\n');
    lineasJS.forEach((l, i) => console.log(color(C.magenta, `    ${String(i+1).padStart(3)}: `) + l));
    console.log(color(C.bold, '    ───────────────────────────────────────────────────────'));

    // Guardar JS generado
    fs.writeFileSync('output.js', codigoJS, 'utf8');
    console.log(color(C.green, '\n    [✓] Código JavaScript guardado en: output.js'));

    // Ejecutar el código generado
    console.log(color(C.bold, '\n    ── Ejecución del código generado ──────────────────────'));
    try {
        // Evaluar dinámicamente usando eval en contexto de módulo
        eval(codigoJS.replace(/^\/\/.*/gm, ''));
    } catch (e) {
        // Ejecutar como archivo temporal
        fs.writeFileSync('/tmp/_tablero_exec.js', codigoJS, 'utf8');
        const { execSync } = await import('child_process');
        try {
            const salida = execSync('node /tmp/_tablero_exec.js', { encoding: 'utf8' });
            process.stdout.write(salida);
        } catch (e2) {
            console.log(color(C.red, `    Error al ejecutar: ${e2.message}`));
        }
    }

    console.log(color(C.bold + C.green, '\n╔══════════════════════════════════════════════════════════╗'));
    console.log(color(C.bold + C.green, '║        ANÁLISIS COMPLETADO EXITOSAMENTE                  ║'));
    console.log(color(C.bold + C.green, '╚══════════════════════════════════════════════════════════╝\n'));
}

main().catch(e => {
    console.error(color(C.red, `Error inesperado: ${e.message}`));
    process.exit(1);
});
