// === Tablero: ventas_mensuales ===
// Código JavaScript generado automáticamente por el Analizador Tablero
// SSL - Sintaxis y Semántica de LP - UTN FRM

const tablero = { nombre: "ventas_mensuales", fuentes: {}, metricas: {}, graficos: [], filtros: [], alertas: [] };

// Fuente: datos_ventas
tablero.fuentes["datos_ventas"] = { tipo: "csv", ruta: "datos/ventas.csv" };
console.log("  Fuente cargada: 'datos_ventas' (tipo: csv) desde " + tablero.fuentes["datos_ventas"].ruta);
// Fuente: api_clientes
tablero.fuentes["api_clientes"] = { tipo: "api", ruta: "https://api.empresa.com/clientes" };
console.log("  Fuente cargada: 'api_clientes' (tipo: api) desde " + tablero.fuentes["api_clientes"].ruta);

// Métrica: total_ventas
tablero.metricas["total_ventas"] = { agregacion: "suma", campo: "datos_ventas.monto", fuente: "datos_ventas", valorSimulado: 5000 };

// Métrica: cantidad_clientes
tablero.metricas["cantidad_clientes"] = { agregacion: "contar", campo: "api_clientes.id", fuente: "api_clientes", valorSimulado: 100 };

// Métrica: venta_promedio
tablero.metricas["venta_promedio"] = { agregacion: "promedio", campo: "datos_ventas.monto", fuente: "datos_ventas", valorSimulado: 42.5 };

// Gráfico: grafico_barras
tablero.graficos.push({ id: "grafico_barras", tipo: "barras", usar: "total_ventas" });

// Gráfico: grafico_clientes
tablero.graficos.push({ id: "grafico_clientes", tipo: "torta", usar: "cantidad_clientes" });

// Filtro: datos_ventas.region == "sur"
tablero.filtros.push({ campo: "datos_ventas.region", operador: "==", valor: "sur" });

// Filtro: datos_ventas.monto > 1000
tablero.filtros.push({ campo: "datos_ventas.monto", operador: ">", valor: 1000 });

// Alerta: si total_ventas < 5000
tablero.alertas.push({ metrica: "total_ventas", operador: "<", valor: 5000, mensaje: "Ventas por debajo del objetivo mensual" });

// Alerta: si cantidad_clientes > 500
tablero.alertas.push({ metrica: "cantidad_clientes", operador: ">", valor: 500, mensaje: "Alta demanda de clientes detectada" });

// --- Ejecución de métricas ---
console.log("  Métrica 'total_ventas': suma(datos_ventas.monto) -> fuente: 'datos_ventas' -> valor simulado: " + tablero.metricas["total_ventas"].valorSimulado);
console.log("  Métrica 'cantidad_clientes': contar(api_clientes.id) -> fuente: 'api_clientes' -> valor simulado: " + tablero.metricas["cantidad_clientes"].valorSimulado);
console.log("  Métrica 'venta_promedio': promedio(datos_ventas.monto) -> fuente: 'datos_ventas' -> valor simulado: " + tablero.metricas["venta_promedio"].valorSimulado);

// --- Renderizado de gráficos ---
console.log("  Gráfico 'grafico_barras' [barras] usando métrica 'total_ventas'");
console.log("  Gráfico 'grafico_clientes' [torta] usando métrica 'cantidad_clientes'");

// --- Evaluación de filtros ---
console.log("  Filtro activo: datos_ventas.region == \"sur\"");
console.log("  Filtro activo: datos_ventas.monto > 1000");

// --- Evaluación de alertas ---
{
  const _val = tablero.metricas["total_ventas"] ? tablero.metricas["total_ventas"].valorSimulado : 0;
  if (_val < 5000) {
    console.log("  ⚠ ALERTA ACTIVADA [total_ventas]: " + "Ventas por debajo del objetivo mensual");
  } else {
    console.log("  ✓ Alerta 'total_ventas': sin activar (valor=" + _val + ")");
  }
}
{
  const _val = tablero.metricas["cantidad_clientes"] ? tablero.metricas["cantidad_clientes"].valorSimulado : 0;
  if (_val > 500) {
    console.log("  ⚠ ALERTA ACTIVADA [cantidad_clientes]: " + "Alta demanda de clientes detectada");
  } else {
    console.log("  ✓ Alerta 'cantidad_clientes': sin activar (valor=" + _val + ")");
  }
}

console.log("\n=== Tablero 'ventas_mensuales' procesado correctamente ===");